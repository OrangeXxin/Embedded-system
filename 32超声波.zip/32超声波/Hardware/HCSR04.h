#ifndef _HCSR04_H
#define _HCSR04_H

void HCSR04_Init(void);

#endif
