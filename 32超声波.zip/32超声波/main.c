#include <REGX52.H>
#include "Delay.h"
#include "LCD1602.h"
#include "UT.h"
#include "UART.H"


unsigned int dis,sp;

void main()
{
    LCD_Init();
    UT_Init();
	UART_Init();
	
	LCD_ShowString(1,1,"speed:");
	
    while(1)
   {
	   P2=0XFF;
	   UT_triggr();
	   sp=measure();
	   Delay(20);
      
	   LCD_ShowNum(1,7,sp,3); 
	   
	   UART_SendByte(sp);
   }
}





