#ifndef __TIMER_H
#define __TIMER_H

void Timer_Init(void);

#endif
