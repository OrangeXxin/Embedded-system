#ifndef __ULTRASOUND_H
#define __ULTRASOUND_H
void Ultrasound_Init(void);
float Test_Distance(void);
#endif
