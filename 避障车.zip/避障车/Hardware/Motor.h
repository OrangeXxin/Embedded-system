#ifndef __MOTOR_H
#define __MOTOR_H
void Motor_Init(void);
void Motor_SetLeftSpeed(int8_t Speed);
void Motor_SetRightSpeed(int8_t Speed);
#endif
