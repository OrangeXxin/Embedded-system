#ifndef __HCSR04_H
#define __HCSR04_H

void HC_SR04_Init(void);
int16_t sonic_mm(void);
float sonic(void);

#endif
