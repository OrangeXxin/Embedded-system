#ifndef __SERIAL_H
#define __SERIAL_H
void Serial_Init(void);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
#endif
